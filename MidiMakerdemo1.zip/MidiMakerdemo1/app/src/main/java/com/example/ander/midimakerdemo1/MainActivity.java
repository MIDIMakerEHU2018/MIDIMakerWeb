package com.example.ander.midimakerdemo1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar tulbar = (Toolbar)findViewById(R.id.my_toolbar);
        setSupportActionBar(tulbar);

    }

    public void mostrar_info(View vista){

        Intent i = new Intent(this,InfoClass.class );
        startActivity(i);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu myMenu){

        getMenuInflater().inflate(R.menu.menu1,myMenu);

        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch(item.getItemId()){

            case R.id.action_info:

                mostrar_info(null);
                return true;

            case R.id.action_config:

                return true;

            default:

                return super.onOptionsItemSelected(item);

        }



    }
}
