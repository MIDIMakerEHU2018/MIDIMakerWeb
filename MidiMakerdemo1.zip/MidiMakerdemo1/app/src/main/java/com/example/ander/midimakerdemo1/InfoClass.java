package com.example.ander.midimakerdemo1;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Ander on 20/03/2018.
 */

public class InfoClass extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }


}
