package com.example.ander.midimakerdemo1;


import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


public class EnviarDatos {

    private String url;
    private String parametroValor = "Hola";

    HttpClient httpClient = new DefaultHttpClient();

    HttpPost request = new HttpPost(url);


    public void enviar(){

        List<NameValuePair> postParameters = new ArrayList<NameValuePair>(1);

        postParameters.add(new BasicNameValuePair("parametrosValor", parametroValor));

        try {
            request.setEntity(new UrlEncodedFormEntity(postParameters));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }


    }




}
